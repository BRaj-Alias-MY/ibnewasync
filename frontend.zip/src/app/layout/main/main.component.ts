import { Component, OnInit , Input} from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Router } from '@angular/router';
import { FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  @Input()
  user_name;
  key;
  expanded: true;
  //title: any  = 'Add Organization';
  constructor(private fb: FormBuilder, private api:ApiService,private route:Router) { }
  menuList : any;
  ngOnInit() {
    this.menuList = [];
    this.key = this.api.getToken() ? this.api.getToken() : '';
    this.user_name = '';
    if(this.api.getUser()){
    let user = this.api.getUser()
    this.user_name = user.fname;
  //onsole.log(this.user_name);
 }
    this.api.menu().subscribe(res=>{
      this.menuList = res.data;
    });
  }
  getClass(path):any{
    return  this.route.url==path? 'active-menu':'';
  }


  logout(){
    this.api.logout();
    this.route.navigate(['/login']);
  }

}
