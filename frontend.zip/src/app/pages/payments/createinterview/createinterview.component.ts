import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { ValidationService } from '../../../services/validation.service';
import { GridOptions } from 'ag-grid-community';
import { ChildMessageRenderer } from '../../../childmessagerender.component';
import {PaymentsService} from '../services/payments.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';


@Component({
  selector: 'app-createinterview',
  templateUrl: './createinterview.component.html',
  styleUrls: ['./createinterview.component.css']
})
export class CreateinterviewComponent implements OnInit {
  questons;
  all;
  up_val: any;
	index = '';
	rpt_btn_name = '';
	update;
	items;
	btn_update = 'Update';
	btn_add = 'Add';
	access;
	IsForUpdate: boolean = false;
	newItem: any = {};
	updatedItem;
	btn_name: string;
	current_page: number;
	start_record: number;
	pages;
	total_records: number;
	grid_tab;
	sh_add: boolean;
	togel_name: string;
	view_item: any;
	private gridOptions: GridOptions;
	private gridApi;
	private gridColumnApi;

	private columnDefs;
	private rowData;
	private context;
	private frameworkComponents;

  constructor(private fb: FormBuilder, private route: Router, private api: PaymentsService, private http: HttpClient) { 
    this.gridOptions = <GridOptions>{
      paginationNumberFormatter: function(params) {
        return '[' + params.value.toLocaleString() + ']';
      },
    };
    this.columnDefs = [
      {headerName: 'Interview ID', field: 'interviewId' },
      {headerName: 'ID', field: 'id', hide:true},
      {
          headerName: "Action",
          cellRenderer: "childMessageRenderer",
          colId: "params",
          value:"id"
  
     }
  ];
    this.frameworkComponents = {
      childMessageRenderer: ChildMessageRenderer
    };
    this.context = { componentParent: this };
  }
  domainval;
  subdomain; 
  selectedDevice;
  mandatory;
  explevel;
  ngOnInit() {
    this.api.get_domain().subscribe(res=> this.domainval = res.data);
    this.api.get_explevel().subscribe(res=> this.explevel = res.data);

    this.grid_tab = [];
		this.sh_add = false;
    this.togel_name = 'Add';
    this.questons = [];
    this.btn_name = 'Save';
    this.view_item = [];
    this.mandatory = [];
		this.current_page = 1;
		this.pages = [];
		this.start_record = 1;
		this.update = false;
		this.access = {addAccess: 0, editAccess: 0,deleteAccess:0,gridAccess:0};
		this.rpt_btn_name = this.btn_add;
		this.up_val = '';

		this.grid();
   }

   createinterviewForm = this.fb.group({
		id:[],
    domainId: [''],
    subDomainId: [''],
    expLevelId: [''],
    start_date: [''],
    end_date: [''],
    duration: [''],
    questionCount:[''],
    questons: []
    });

    createinterviewrepeatForm = this.fb.group({
      question: ['']
    });


    add_togel() {
      this.sh_add = this.sh_add ? false : true;
      this.togel_name = this.togel_name == 'Add' ? 'Close' : 'Add';
      this.btn_name = 'Save';
      this.createinterviewForm.patchValue({ domainId: [''],subDomainId: [''], expLevelId: '',start_date: '',end_date: '',duration: '',questionCount: '', });
      this.questons = [];
  
    }
    
	onGridReady(params) {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;

		params.api.sizeColumnsToFit();
  }

   onChange($event) {
    this.api.get_subdomain(this.selectedDevice).subscribe(res=> this.subdomain = res.data);

    //this.createinterviewForm.patchValue({ subdomain: '' });
   }


  
  
  addSellingPoint() {
		if (this.rpt_btn_name == this.btn_add) {
      for(let i=0;i<this.all.length;i++){
        if(this.all[i].id==this.createinterviewrepeatForm.value.question){
          Swal.fire('info..', 'question already inserted.', 'info');
          break;
        }else{
          this.questons.push(this.all[i]);
        }
      }
			//this.questons.push(this.createinterviewrepeatForm.value);
		} else if (this.rpt_btn_name == this.btn_update) {
			this.questons[this.index] = this.createinterviewrepeatForm.value;
		} else {
			//Swal('Error in Form. Please try again later.');
		}
	//this.clear_fields();
		this.rpt_btn_name = this.btn_add;
  }
  

  getquestions(){
    let doman = this.createinterviewForm.value.domainId;
    let subdoman = this.createinterviewForm.value.subDomainId;
    console.log(subdoman);
    this.api.getquestion(doman,subdoman).subscribe((res) => {
      if (res.status) {
       // console.log(res.data.mandate);
       this.all = res.data.all;
       this.mandatory = res.data.mandate;   
       this.questons = this.mandatory;
      console.log(this.all);
      console.log(this.mandatory);
       // console.log(this.questons.length);

      } else {
        //this.loading.hide();
        //Swal('Oops...', 'Something went wrong!', 'error');
      }
    });
  }

  deleteSellingPoint(index) {
    this.questons.splice(index, 1);
   // console.log(this.questons.length);
}

   grid(){
    this.api.getinterviews().subscribe(data => {
      this.access = data.access;
			if (this.access && this.access.gridAccess) {
				this.grid_tab = data.data;
			}
			this.sh_add = false;
			this.togel_name = 'Add';
			this.btn_name = 'Save';
			//this.loading.hide();
			this.view_item = [];
      }); 
   }

   onSubmit(){
    let questionnt = this.createinterviewForm.value.questionCount;
   // console.log(questionnt);
   // console.log(this.questons.length);
    this.createinterviewForm.value.questons = this.questons;
     console.log(this.createinterviewForm.value);
     if(this.questons.length <  questionnt){
        this.api.createinterview(this.createinterviewForm.value).subscribe((res) => {
       if (res.status) {
         //console.log(res);
         this.grid(); 
        this.sh_add=false;
        Swal.fire('Success..', 'Interview Created successfully.', 'success'); 

       } else {
         //this.loading.hide();
         Swal.fire('Oops...', 'Something went wrong!', 'error');
       }
     }); 

    }
    else{
      Swal.fire('Oops...', 'Something went wrong!', 'error');

    }
  
   
  }

}
